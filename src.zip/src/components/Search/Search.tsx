import "./Search.css";

const Search =()=>{
    return(
        <input type="text" className="search" placeholder="Buscar" />
    )
}
export default Search;