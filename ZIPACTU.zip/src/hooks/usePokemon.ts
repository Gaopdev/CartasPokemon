//import { POKEMON_MOCK } from "../data"
import { useState, useEffect } from "react"
import type { Pokemon } from "../types"

const usePokemons =() =>{
    //Manejo de estado
    //const [pokemons, setPokemon] = useState(POKEMON_MOCK)
    const [pokemons, setPokemon] = useState<Pokemon[]>([])
    const traerPokemons = async()=>{
        try{
            //Mensajer que va por los atos
            const respuesta = await fetch('https://pokeapi.co/api/v2/pokemon?limit=20')
            //Paquete que vamos a abrir
            const datos = await respuesta.json()
            //Usar map para selecionar sololos datos que quiero
            const listadoReal = datos.results.map((p:any, index:number)=>({
                id: index+1,
                nombreBase: p.name,
                nombreEvo: "Pokemon Shiny",
                imgBase: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${index+1}.png`,
                imgEvo: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/${index+1}.png`,
                estado: false
            }))
            setPokemon(listadoReal)
        }
        catch(error){
            console.error("Hubo error al traer los datos", error)
        }
    }
    useEffect(()=>{
        traerPokemons()
    },[])

    //Funcion de evolucionar
    const evolucionar = (id:number)=>{
    setPokemon(prev => prev.map(p=> p.id==id?{...p,evo:!p.evo}:p))
    }
    
    return{
        pokemons,
        evolucionar
    }
}
export default usePokemons