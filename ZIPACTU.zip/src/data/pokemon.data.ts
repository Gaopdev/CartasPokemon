import { pikachu, raichu, charmander, charmeleon } from '../assets'
import type {Pokemon} from '../types'

const POKEMON_MOCK:Pokemon[]=[
    {
        id:1,
        nombreBase:"Pikachu",
        nombreEvo:"Raichu",
        imgBase:pikachu,
        imgEvo:raichu,
        evo:false
    },
    {
        id:2,
        nombreBase:"Charmander",
        nombreEvo:"Charmeleon", 
        imgBase:charmander,
        imgEvo:charmeleon,
        evo:false
    }
]

export default POKEMON_MOCK