import './App.css'
import {Card} from './components'
import { pikachu, raichu, charmander, charmeleon } from './assets'
import {useState} from 'react'

//Componente
//hook -> useState es un hook de estado
function App() {
  /*
  const [evolucion, setEstado]= useState(false)
  const [img, setImg]= useState(pikachu)
  const[nombre, setNombre] = useState('Pikachu')
*/
  const [pokemons, setPokemon] = useState([
    {
      id:1,
      nombreBase:"Pikachu",
      nombreEvo:"Raichu",
      imgBase:pikachu,
      imgEvo:raichu,
      evo:false
    },
    {
      id:2,
      nombreBase:"Charmander",
      nombreEvo:"Charmeleon",
      imgBase:charmander,
      imgEvo:charmeleon,
      evo:false
    }
  ])
  
  /*const evolucionar=()=>{
    setEstado(!evolucion)
    setImg(img==pikachu?raichu:pikachu)
    setNombre(nombre=='Pikachu'?'Raichu':'Pikachu')
  }*/

  const evolucionr = (id:number)=>{
    setPokemon(prev => prev.map(p=> p.id==id?{...p,evo:!p.evo}:p))
  }
  return(
    //Fragmento
    <>
    {
      pokemons.map((p)=>(
        <Card 
        key={p.id}
        estado={p.evo}
        imagen={p.evo?p.imgEvo:p.imgBase} 
        nombre={p.evo?p.nombreEvo:p.nombreBase} 
        descripcion='pokemon' 
        texto='evolucionar' 
        accion={()=>evolucionr(p.id)} 
        />
      ))
    }
    </>
  )
}
export default App