import "./card.css"

interface Props{
    imagen: string,
    nombre: string,
    descripcion: string,
    texto: string,
    
    accion:()=>void,

    estado:boolean
}
function Card({imagen,nombre,descripcion,texto,accion,estado}:Props){
    return(
        <div className={`card ${estado?"card-evo":"card-normal"}`} >
            <img src={imagen} alt=""/>
            <h3>{nombre}</h3>
            <p>{descripcion}</p>
            <span onClick={accion}>{texto}</span>
        </div>
    )
}

export default Card;